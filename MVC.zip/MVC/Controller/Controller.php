<?php
require_once(__DIR__ . '/../model/User.php');

class AuthController {
    public function login($id, $pass) {
        if (User::validate($id, $pass)) {
            $_SESSION['status'] = true;
            header('Location: home.php');
            exit();
        } else {
            return "Invalid ID or Password!";
        }
    }

    public function logout() {
        session_destroy();
        header('Location: login.php');
        exit();
    }
}
