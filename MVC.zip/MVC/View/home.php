<!DOCTYPE html>
<html>
<head><title>Home</title></head>
<body>
    <h1>Welcome to Home Page</h1>
    <form method="post" action="logout.php">
        <input type="submit" name="logOut" value="Logout">
    </form>
</body>
</html>
