<?php
class User {
    public static function validate($id, $pass) {
        
        return !empty($id) && !empty($pass);
    }
}