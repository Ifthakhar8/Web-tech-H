<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Social Media App</title>
    <link rel="stylesheet" href="/social-media/public/css/style.css">
</head>
<body>
    <div class="container">
        <?php echo $content; ?>
    </div>
    
    <script src="/social-media/public/js/app.js"></script>
    <script>
        
    </script>
</body>
</html>